f = open('text.txt', 'w', encoding='utf-8')
text = 'El profesor jesus nieves es el mas cool del mundo y con mas aura jejeje\n'
text2 = 'El grupo de la clase de programacion es el mejor del mundo y con mas aura jejeje'
f.write(text)
f.write(text2)
f.close()

f = open('text.txt', 'r', encoding='utf-8')
text = f.read()
print(text)
f.close()