import discord 
from discord import commands
from bot_logic import gen_pass
import random, os
import openai

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'Hemos iniciado sesión como {bot.user}')
    
@bot.command()
async def hello(ctx):
    await ctx.send(f"Hola, soy un bot {bot.user}!")
    
@bot.command()
async def heh(ctx, count_heh = 5):
    await ctx.send("He" * count_heh)
    
@bot.command()
async def bye(ctx):
    await ctx.send("\U0001f642")
    
@bot.command()
async def password(ctx):
    length = int(input("Ingrese la longitud de la contraseña: "))
    password = gen_pass(length)
    await ctx.send(f"Tu contraseña es: {password}")
    
@bot.command()
async def chiste(ctx):
    await ctx.send("¿Qué le dice un techo a otro techo? ¡techodemenos!")

imagen_anterior = None
@bot.command()
async def meme(ctx):
    global imagen_anterior

    imagenes = os.listdir("images")
    if not imagenes:
        await ctx.send("No hay imágenes en la carpeta images.")
        return

    img_name = random.choice([nombre for nombre in imagenes if nombre != imagen_anterior] or imagenes)
    imagen_anterior = img_name

    with open(os.path.join("images", img_name), "rb") as f:
        await ctx.send(file=discord.File(f))
@bot.command()
async def chat(ctx, *, prompt):
    openai.api_key = "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"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=100
    )
    await ctx.send(response.choices[0].text.strip())



    

bot.run("MTU1NTk4MzEwMDQzNjAyMTM1OA.GkHrtO.nTCczaZ130RRc_WgEnKGxdDHbBhvnKAZFdnVU4")